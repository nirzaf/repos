﻿namespace PCJ_System
{
    partial class Admin_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Menu));
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.hello = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.b2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton7 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton6 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton8 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton5 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.SC_JEWLRY = new Bunifu.Framework.UI.BunifuFlatButton();
            this.SC_GEMS = new Bunifu.Framework.UI.BunifuFlatButton();
            this.SC_GE = new Bunifu.Framework.UI.BunifuFlatButton();
            this.SC_JE = new Bunifu.Framework.UI.BunifuFlatButton();
            this.invoice_Certificate1 = new PCJ_System.Invoice_Certificate();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.scStocks_Gems1 = new PCJ_System.SCStocks_Gems();
            this.stocks_Gems1 = new PCJ_System.Stocks_Gems();
            this.scStocks_Jewelry1 = new PCJ_System.SCStocks_Jewelry();
            this.stocks_Jewelry1 = new PCJ_System.Stocks_Jewelry();
            this.status_of_Stocks1 = new PCJ_System.Status_of_Stocks();
            this.newUser1 = new PCJ_System.NewUser();
            this.invoice_Certificate2 = new PCJ_System.Invoice_Certificate();
            this.outstandingstocks1 = new PCJ_System.Outstandingstocks();
            this.dashBoard1 = new PCJ_System.DashBoard();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox10
            // 
            this.pictureBox10.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(1180, 0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(33, 36);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 24;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(1147, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(33, 36);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 23;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(9, 6);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 32);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1114, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 36);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.pictureBox6);
            this.panel2.Controls.Add(this.pictureBox9);
            this.panel2.Controls.Add(this.pictureBox10);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1215, 38);
            this.panel2.TabIndex = 26;
            // 
            // hello
            // 
            this.hello.AutoSize = true;
            this.hello.Font = new System.Drawing.Font("Perpetua Titling MT", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hello.ForeColor = System.Drawing.Color.White;
            this.hello.Location = new System.Drawing.Point(92, 105);
            this.hello.Name = "hello";
            this.hello.Size = new System.Drawing.Size(53, 21);
            this.hello.TabIndex = 91;
            this.hello.Text = "User";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(66, 76);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 20);
            this.label1.TabIndex = 27;
            this.label1.Text = "Logged In By";
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "              DASHBOARD";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 60D;
            this.bunifuFlatButton2.IsTab = true;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(0, 163);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = true;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(248, 48);
            this.bunifuFlatButton2.TabIndex = 28;
            this.bunifuFlatButton2.Text = "              DASHBOARD";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // b2
            // 
            this.b2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.b2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.b2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b2.BorderRadius = 0;
            this.b2.ButtonText = "STOCK CONTROL";
            this.b2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.b2.DisabledColor = System.Drawing.Color.Gray;
            this.b2.Iconcolor = System.Drawing.Color.Transparent;
            this.b2.Iconimage = ((System.Drawing.Image)(resources.GetObject("b2.Iconimage")));
            this.b2.Iconimage_right = null;
            this.b2.Iconimage_right_Selected = null;
            this.b2.Iconimage_Selected = null;
            this.b2.IconMarginLeft = 0;
            this.b2.IconMarginRight = 0;
            this.b2.IconRightVisible = true;
            this.b2.IconRightZoom = 0D;
            this.b2.IconVisible = true;
            this.b2.IconZoom = 50D;
            this.b2.IsTab = true;
            this.b2.Location = new System.Drawing.Point(0, 265);
            this.b2.Margin = new System.Windows.Forms.Padding(4);
            this.b2.Name = "b2";
            this.b2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.b2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.b2.OnHoverTextColor = System.Drawing.Color.White;
            this.b2.selected = false;
            this.b2.Size = new System.Drawing.Size(248, 48);
            this.b2.TabIndex = 31;
            this.b2.Text = "STOCK CONTROL";
            this.b2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.b2.Textcolor = System.Drawing.Color.White;
            this.b2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "INVOICE";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 50D;
            this.bunifuFlatButton1.IsTab = true;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 214);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(248, 48);
            this.bunifuFlatButton1.TabIndex = 32;
            this.bunifuFlatButton1.Text = "INVOICE";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 639);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(248, 61);
            this.panel4.TabIndex = 28;
            // 
            // bunifuFlatButton7
            // 
            this.bunifuFlatButton7.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton7.BorderRadius = 0;
            this.bunifuFlatButton7.ButtonText = "                            Jewelry Entry";
            this.bunifuFlatButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton7.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.bunifuFlatButton7.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.Iconimage = null;
            this.bunifuFlatButton7.Iconimage_right = null;
            this.bunifuFlatButton7.Iconimage_right_Selected = null;
            this.bunifuFlatButton7.Iconimage_Selected = null;
            this.bunifuFlatButton7.IconMarginLeft = 0;
            this.bunifuFlatButton7.IconMarginRight = 0;
            this.bunifuFlatButton7.IconRightVisible = true;
            this.bunifuFlatButton7.IconRightZoom = 0D;
            this.bunifuFlatButton7.IconVisible = true;
            this.bunifuFlatButton7.IconZoom = 60D;
            this.bunifuFlatButton7.IsTab = true;
            this.bunifuFlatButton7.Location = new System.Drawing.Point(0, 318);
            this.bunifuFlatButton7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton7.Name = "bunifuFlatButton7";
            this.bunifuFlatButton7.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton7.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton7.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton7.selected = false;
            this.bunifuFlatButton7.Size = new System.Drawing.Size(281, 29);
            this.bunifuFlatButton7.TabIndex = 34;
            this.bunifuFlatButton7.Text = "                            Jewelry Entry";
            this.bunifuFlatButton7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton7.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton7.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bunifuFlatButton7.Click += new System.EventHandler(this.bunifuFlatButton7_Click);
            // 
            // bunifuFlatButton6
            // 
            this.bunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton6.BorderRadius = 0;
            this.bunifuFlatButton6.ButtonText = "                            Gem Entry";
            this.bunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.Iconimage = null;
            this.bunifuFlatButton6.Iconimage_right = null;
            this.bunifuFlatButton6.Iconimage_right_Selected = null;
            this.bunifuFlatButton6.Iconimage_Selected = null;
            this.bunifuFlatButton6.IconMarginLeft = 0;
            this.bunifuFlatButton6.IconMarginRight = 0;
            this.bunifuFlatButton6.IconRightVisible = true;
            this.bunifuFlatButton6.IconRightZoom = 0D;
            this.bunifuFlatButton6.IconVisible = true;
            this.bunifuFlatButton6.IconZoom = 60D;
            this.bunifuFlatButton6.IsTab = true;
            this.bunifuFlatButton6.Location = new System.Drawing.Point(-34, 349);
            this.bunifuFlatButton6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton6.Name = "bunifuFlatButton6";
            this.bunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton6.selected = false;
            this.bunifuFlatButton6.Size = new System.Drawing.Size(281, 29);
            this.bunifuFlatButton6.TabIndex = 35;
            this.bunifuFlatButton6.Text = "                            Gem Entry";
            this.bunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton6.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton6.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bunifuFlatButton6.Click += new System.EventHandler(this.bunifuFlatButton6_Click);
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 0;
            this.bunifuFlatButton4.ButtonText = "                   Stock Status ";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = null;
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 60D;
            this.bunifuFlatButton4.IsTab = true;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(-1, 379);
            this.bunifuFlatButton4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(249, 29);
            this.bunifuFlatButton4.TabIndex = 36;
            this.bunifuFlatButton4.Text = "                   Stock Status ";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bunifuFlatButton4.Click += new System.EventHandler(this.bunifuFlatButton4_Click);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "MANAGE USERS";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton3.Iconimage")));
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 50D;
            this.bunifuFlatButton3.IsTab = true;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(0, 439);
            this.bunifuFlatButton3.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(248, 48);
            this.bunifuFlatButton3.TabIndex = 38;
            this.bunifuFlatButton3.Text = "MANAGE USERS";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.bunifuFlatButton3.Visible = false;
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.panel1.Controls.Add(this.bunifuFlatButton8);
            this.panel1.Controls.Add(this.bunifuFlatButton5);
            this.panel1.Controls.Add(this.SC_JEWLRY);
            this.panel1.Controls.Add(this.SC_GEMS);
            this.panel1.Controls.Add(this.SC_GE);
            this.panel1.Controls.Add(this.SC_JE);
            this.panel1.Controls.Add(this.invoice_Certificate1);
            this.panel1.Controls.Add(this.hello);
            this.panel1.Controls.Add(this.bunifuFlatButton3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.bunifuFlatButton4);
            this.panel1.Controls.Add(this.bunifuFlatButton6);
            this.panel1.Controls.Add(this.bunifuFlatButton7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.bunifuFlatButton1);
            this.panel1.Controls.Add(this.b2);
            this.panel1.Controls.Add(this.bunifuFlatButton2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 38);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(248, 700);
            this.panel1.TabIndex = 27;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // bunifuFlatButton8
            // 
            this.bunifuFlatButton8.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton8.BorderRadius = 0;
            this.bunifuFlatButton8.ButtonText = "                   Out Standing Stock ";
            this.bunifuFlatButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton8.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.bunifuFlatButton8.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton8.Iconimage = null;
            this.bunifuFlatButton8.Iconimage_right = null;
            this.bunifuFlatButton8.Iconimage_right_Selected = null;
            this.bunifuFlatButton8.Iconimage_Selected = null;
            this.bunifuFlatButton8.IconMarginLeft = 0;
            this.bunifuFlatButton8.IconMarginRight = 0;
            this.bunifuFlatButton8.IconRightVisible = true;
            this.bunifuFlatButton8.IconRightZoom = 0D;
            this.bunifuFlatButton8.IconVisible = true;
            this.bunifuFlatButton8.IconZoom = 60D;
            this.bunifuFlatButton8.IsTab = true;
            this.bunifuFlatButton8.Location = new System.Drawing.Point(-1, 409);
            this.bunifuFlatButton8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton8.Name = "bunifuFlatButton8";
            this.bunifuFlatButton8.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton8.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton8.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton8.selected = false;
            this.bunifuFlatButton8.Size = new System.Drawing.Size(249, 29);
            this.bunifuFlatButton8.TabIndex = 98;
            this.bunifuFlatButton8.Text = "                   Out Standing Stock ";
            this.bunifuFlatButton8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton8.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton8.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bunifuFlatButton8.Click += new System.EventHandler(this.bunifuFlatButton8_Click_2);
            // 
            // bunifuFlatButton5
            // 
            this.bunifuFlatButton5.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.bunifuFlatButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton5.BorderRadius = 0;
            this.bunifuFlatButton5.ButtonText = "UPDATE CURRENCY";
            this.bunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton5.Iconimage")));
            this.bunifuFlatButton5.Iconimage_right = null;
            this.bunifuFlatButton5.Iconimage_right_Selected = null;
            this.bunifuFlatButton5.Iconimage_Selected = null;
            this.bunifuFlatButton5.IconMarginLeft = 0;
            this.bunifuFlatButton5.IconMarginRight = 0;
            this.bunifuFlatButton5.IconRightVisible = true;
            this.bunifuFlatButton5.IconRightZoom = 0D;
            this.bunifuFlatButton5.IconVisible = true;
            this.bunifuFlatButton5.IconZoom = 50D;
            this.bunifuFlatButton5.IsTab = true;
            this.bunifuFlatButton5.Location = new System.Drawing.Point(0, 493);
            this.bunifuFlatButton5.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton5.Name = "bunifuFlatButton5";
            this.bunifuFlatButton5.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton5.selected = false;
            this.bunifuFlatButton5.Size = new System.Drawing.Size(247, 48);
            this.bunifuFlatButton5.TabIndex = 97;
            this.bunifuFlatButton5.Text = "UPDATE CURRENCY";
            this.bunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton5.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton5.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.bunifuFlatButton5.Visible = false;
            this.bunifuFlatButton5.Click += new System.EventHandler(this.bunifuFlatButton5_Click_4);
            // 
            // SC_JEWLRY
            // 
            this.SC_JEWLRY.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.SC_JEWLRY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_JEWLRY.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SC_JEWLRY.BorderRadius = 0;
            this.SC_JEWLRY.ButtonText = "                   Jewelry Entry";
            this.SC_JEWLRY.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SC_JEWLRY.DisabledColor = System.Drawing.Color.Gray;
            this.SC_JEWLRY.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.SC_JEWLRY.Iconcolor = System.Drawing.Color.Transparent;
            this.SC_JEWLRY.Iconimage = null;
            this.SC_JEWLRY.Iconimage_right = null;
            this.SC_JEWLRY.Iconimage_right_Selected = null;
            this.SC_JEWLRY.Iconimage_Selected = null;
            this.SC_JEWLRY.IconMarginLeft = 0;
            this.SC_JEWLRY.IconMarginRight = 0;
            this.SC_JEWLRY.IconRightVisible = true;
            this.SC_JEWLRY.IconRightZoom = 0D;
            this.SC_JEWLRY.IconVisible = true;
            this.SC_JEWLRY.IconZoom = 60D;
            this.SC_JEWLRY.IsTab = true;
            this.SC_JEWLRY.Location = new System.Drawing.Point(0, 318);
            this.SC_JEWLRY.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SC_JEWLRY.Name = "SC_JEWLRY";
            this.SC_JEWLRY.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_JEWLRY.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.SC_JEWLRY.OnHoverTextColor = System.Drawing.Color.White;
            this.SC_JEWLRY.selected = false;
            this.SC_JEWLRY.Size = new System.Drawing.Size(248, 29);
            this.SC_JEWLRY.TabIndex = 95;
            this.SC_JEWLRY.Text = "                   Jewelry Entry";
            this.SC_JEWLRY.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SC_JEWLRY.Textcolor = System.Drawing.Color.White;
            this.SC_JEWLRY.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.SC_JEWLRY.Visible = false;
            this.SC_JEWLRY.Click += new System.EventHandler(this.bunifuFlatButton8_Click_1);
            // 
            // SC_GEMS
            // 
            this.SC_GEMS.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.SC_GEMS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_GEMS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SC_GEMS.BorderRadius = 0;
            this.SC_GEMS.ButtonText = "                   Gem Entry";
            this.SC_GEMS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SC_GEMS.DisabledColor = System.Drawing.Color.Gray;
            this.SC_GEMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.SC_GEMS.Iconcolor = System.Drawing.Color.Transparent;
            this.SC_GEMS.Iconimage = null;
            this.SC_GEMS.Iconimage_right = null;
            this.SC_GEMS.Iconimage_right_Selected = null;
            this.SC_GEMS.Iconimage_Selected = null;
            this.SC_GEMS.IconMarginLeft = 0;
            this.SC_GEMS.IconMarginRight = 0;
            this.SC_GEMS.IconRightVisible = true;
            this.SC_GEMS.IconRightZoom = 0D;
            this.SC_GEMS.IconVisible = true;
            this.SC_GEMS.IconZoom = 60D;
            this.SC_GEMS.IsTab = true;
            this.SC_GEMS.Location = new System.Drawing.Point(0, 349);
            this.SC_GEMS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SC_GEMS.Name = "SC_GEMS";
            this.SC_GEMS.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_GEMS.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.SC_GEMS.OnHoverTextColor = System.Drawing.Color.White;
            this.SC_GEMS.selected = false;
            this.SC_GEMS.Size = new System.Drawing.Size(248, 29);
            this.SC_GEMS.TabIndex = 94;
            this.SC_GEMS.Text = "                   Gem Entry";
            this.SC_GEMS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SC_GEMS.Textcolor = System.Drawing.Color.White;
            this.SC_GEMS.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.SC_GEMS.Visible = false;
            this.SC_GEMS.Click += new System.EventHandler(this.bunifuFlatButton5_Click_2);
            // 
            // SC_GE
            // 
            this.SC_GE.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.SC_GE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_GE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SC_GE.BorderRadius = 0;
            this.SC_GE.ButtonText = "                   Gem Entry";
            this.SC_GE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SC_GE.DisabledColor = System.Drawing.Color.Gray;
            this.SC_GE.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.SC_GE.Iconcolor = System.Drawing.Color.Transparent;
            this.SC_GE.Iconimage = null;
            this.SC_GE.Iconimage_right = null;
            this.SC_GE.Iconimage_right_Selected = null;
            this.SC_GE.Iconimage_Selected = null;
            this.SC_GE.IconMarginLeft = 0;
            this.SC_GE.IconMarginRight = 0;
            this.SC_GE.IconRightVisible = true;
            this.SC_GE.IconRightZoom = 0D;
            this.SC_GE.IconVisible = true;
            this.SC_GE.IconZoom = 60D;
            this.SC_GE.IsTab = true;
            this.SC_GE.Location = new System.Drawing.Point(0, 349);
            this.SC_GE.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SC_GE.Name = "SC_GE";
            this.SC_GE.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_GE.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.SC_GE.OnHoverTextColor = System.Drawing.Color.White;
            this.SC_GE.selected = false;
            this.SC_GE.Size = new System.Drawing.Size(248, 29);
            this.SC_GE.TabIndex = 93;
            this.SC_GE.Text = "                   Gem Entry";
            this.SC_GE.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SC_GE.Textcolor = System.Drawing.Color.White;
            this.SC_GE.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.SC_GE.Visible = false;
            this.SC_GE.Click += new System.EventHandler(this.bunifuFlatButton9_Click);
            // 
            // SC_JE
            // 
            this.SC_JE.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.SC_JE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_JE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SC_JE.BorderRadius = 0;
            this.SC_JE.ButtonText = "                   Jewelry Entry";
            this.SC_JE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SC_JE.DisabledColor = System.Drawing.Color.Gray;
            this.SC_JE.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.SC_JE.Iconcolor = System.Drawing.Color.Transparent;
            this.SC_JE.Iconimage = null;
            this.SC_JE.Iconimage_right = null;
            this.SC_JE.Iconimage_right_Selected = null;
            this.SC_JE.Iconimage_Selected = null;
            this.SC_JE.IconMarginLeft = 0;
            this.SC_JE.IconMarginRight = 0;
            this.SC_JE.IconRightVisible = true;
            this.SC_JE.IconRightZoom = 0D;
            this.SC_JE.IconVisible = true;
            this.SC_JE.IconZoom = 60D;
            this.SC_JE.IsTab = true;
            this.SC_JE.Location = new System.Drawing.Point(0, 318);
            this.SC_JE.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SC_JE.Name = "SC_JE";
            this.SC_JE.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(51)))), ((int)(((byte)(61)))));
            this.SC_JE.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(135)))), ((int)(((byte)(229)))));
            this.SC_JE.OnHoverTextColor = System.Drawing.Color.White;
            this.SC_JE.selected = false;
            this.SC_JE.Size = new System.Drawing.Size(248, 29);
            this.SC_JE.TabIndex = 92;
            this.SC_JE.Text = "                   Jewelry Entry";
            this.SC_JE.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SC_JE.Textcolor = System.Drawing.Color.White;
            this.SC_JE.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.SC_JE.Visible = false;
            this.SC_JE.Click += new System.EventHandler(this.bunifuFlatButton8_Click);
            // 
            // invoice_Certificate1
            // 
            this.invoice_Certificate1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.invoice_Certificate1.Location = new System.Drawing.Point(283, 39);
            this.invoice_Certificate1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.invoice_Certificate1.Name = "invoice_Certificate1";
            this.invoice_Certificate1.Size = new System.Drawing.Size(1580, 1048);
            this.invoice_Certificate1.TabIndex = 33;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(101, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 46);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 26;
            this.pictureBox2.TabStop = false;
            // 
            // scStocks_Gems1
            // 
            this.scStocks_Gems1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.scStocks_Gems1.Location = new System.Drawing.Point(250, 38);
            this.scStocks_Gems1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.scStocks_Gems1.Name = "scStocks_Gems1";
            this.scStocks_Gems1.Size = new System.Drawing.Size(1193, 860);
            this.scStocks_Gems1.TabIndex = 36;
            // 
            // stocks_Gems1
            // 
            this.stocks_Gems1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.stocks_Gems1.Location = new System.Drawing.Point(250, 38);
            this.stocks_Gems1.Margin = new System.Windows.Forms.Padding(2);
            this.stocks_Gems1.Name = "stocks_Gems1";
            this.stocks_Gems1.Size = new System.Drawing.Size(1193, 860);
            this.stocks_Gems1.TabIndex = 35;
            // 
            // scStocks_Jewelry1
            // 
            this.scStocks_Jewelry1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.scStocks_Jewelry1.Location = new System.Drawing.Point(250, 38);
            this.scStocks_Jewelry1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.scStocks_Jewelry1.Name = "scStocks_Jewelry1";
            this.scStocks_Jewelry1.Size = new System.Drawing.Size(1193, 860);
            this.scStocks_Jewelry1.TabIndex = 34;
            // 
            // stocks_Jewelry1
            // 
            this.stocks_Jewelry1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.stocks_Jewelry1.Location = new System.Drawing.Point(250, 38);
            this.stocks_Jewelry1.Margin = new System.Windows.Forms.Padding(2);
            this.stocks_Jewelry1.Name = "stocks_Jewelry1";
            this.stocks_Jewelry1.Size = new System.Drawing.Size(1193, 860);
            this.stocks_Jewelry1.TabIndex = 33;
            // 
            // status_of_Stocks1
            // 
            this.status_of_Stocks1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.status_of_Stocks1.Location = new System.Drawing.Point(250, 38);
            this.status_of_Stocks1.Margin = new System.Windows.Forms.Padding(2);
            this.status_of_Stocks1.Name = "status_of_Stocks1";
            this.status_of_Stocks1.Size = new System.Drawing.Size(1193, 860);
            this.status_of_Stocks1.TabIndex = 30;
            // 
            // newUser1
            // 
            this.newUser1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.newUser1.Location = new System.Drawing.Point(250, 38);
            this.newUser1.Margin = new System.Windows.Forms.Padding(2);
            this.newUser1.Name = "newUser1";
            this.newUser1.Size = new System.Drawing.Size(1193, 860);
            this.newUser1.TabIndex = 28;
            // 
            // invoice_Certificate2
            // 
            this.invoice_Certificate2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.invoice_Certificate2.Location = new System.Drawing.Point(250, 38);
            this.invoice_Certificate2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.invoice_Certificate2.Name = "invoice_Certificate2";
            this.invoice_Certificate2.Size = new System.Drawing.Size(1193, 804);
            this.invoice_Certificate2.TabIndex = 37;
            // 
            // outstandingstocks1
            // 
            this.outstandingstocks1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.outstandingstocks1.Location = new System.Drawing.Point(250, 38);
            this.outstandingstocks1.Margin = new System.Windows.Forms.Padding(2);
            this.outstandingstocks1.Name = "outstandingstocks1";
            this.outstandingstocks1.Size = new System.Drawing.Size(1183, 860);
            this.outstandingstocks1.TabIndex = 38;
            // 
            // dashBoard1
            // 
            this.dashBoard1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.dashBoard1.Location = new System.Drawing.Point(250, 38);
            this.dashBoard1.Margin = new System.Windows.Forms.Padding(2);
            this.dashBoard1.Name = "dashBoard1";
            this.dashBoard1.Size = new System.Drawing.Size(1193, 860);
            this.dashBoard1.TabIndex = 39;
            // 
            // Admin_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.ClientSize = new System.Drawing.Size(1215, 738);
            this.Controls.Add(this.dashBoard1);
            this.Controls.Add(this.outstandingstocks1);
            this.Controls.Add(this.invoice_Certificate2);
            this.Controls.Add(this.scStocks_Gems1);
            this.Controls.Add(this.stocks_Gems1);
            this.Controls.Add(this.scStocks_Jewelry1);
            this.Controls.Add(this.stocks_Jewelry1);
            this.Controls.Add(this.status_of_Stocks1);
            this.Controls.Add(this.newUser1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Admin_Menu";
            this.Text = "Admin_Menu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admin_Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuFlatButton b2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label hello;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Invoice_Certificate invoice_Certificate1;
        public Bunifu.Framework.UI.BunifuFlatButton SC_JE;
        public Bunifu.Framework.UI.BunifuFlatButton SC_GE;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton7;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton6;
        public Bunifu.Framework.UI.BunifuFlatButton SC_GEMS;
        public Bunifu.Framework.UI.BunifuFlatButton SC_JEWLRY;
        private NewUser newUser1;
        private Status_of_Stocks status_of_Stocks1;
        private Stocks_Jewelry stocks_Jewelry1;
        private SCStocks_Jewelry scStocks_Jewelry1;
        private Stocks_Gems stocks_Gems1;
        private SCStocks_Gems scStocks_Gems1;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton5;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton8;
        private Invoice_Certificate invoice_Certificate2;
        private Outstandingstocks outstandingstocks1;
        private DashBoard dashBoard1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}