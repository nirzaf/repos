﻿namespace PCJ_System
{
    partial class In_certi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(In_certi));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbInvTyp = new System.Windows.Forms.ComboBox();
            this.txtInvNo = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblCost = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.dgvItem = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSpecification = new System.Windows.Forms.TextBox();
            this.cmbItmTyp = new System.Windows.Forms.ComboBox();
            this.lblSpecification = new System.Windows.Forms.Label();
            this.lblGemWeight = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtGemWeight = new System.Windows.Forms.TextBox();
            this.txtNoPieces = new System.Windows.Forms.TextBox();
            this.lblNoPieces = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.txtAddress = new System.Windows.Forms.ComboBox();
            this.txtCusNm = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Invdelete = new System.Windows.Forms.Button();
            this.Dashlabel = new System.Windows.Forms.Label();
            this.InvUpdate = new System.Windows.Forms.Button();
            this.cmbCurrency1 = new System.Windows.Forms.ComboBox();
            this.cmbCardTyp = new System.Windows.Forms.ComboBox();
            this.txtRate1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtRate2 = new System.Windows.Forms.TextBox();
            this.cmbPaymentTyp = new System.Windows.Forms.ComboBox();
            this.txtcardamt = new System.Windows.Forms.TextBox();
            this.lblcardamt = new System.Windows.Forms.Label();
            this.txtRate3 = new System.Windows.Forms.TextBox();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblCardTyp = new System.Windows.Forms.Label();
            this.txtAmt1 = new System.Windows.Forms.TextBox();
            this.txtTot1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.btnPrntInvoice = new System.Windows.Forms.Button();
            this.txtTot2 = new System.Windows.Forms.TextBox();
            this.txtAmt2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtTot3 = new System.Windows.Forms.TextBox();
            this.cmbCurrency2 = new System.Windows.Forms.ComboBox();
            this.txtAmt3 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbCurrency3 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.checkBox_disable = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.Print_invoice_Pre = new System.Windows.Forms.Button();
            this.Print_certificate_Pre = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnaddstock = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.PrntInPre = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.DVPrintPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.DVPrintDocument = new System.Drawing.Printing.PrintDocument();
            this.INPrintDocument = new System.Drawing.Printing.PrintDocument();
            this.btnremovestock = new System.Windows.Forms.Button();
            this.INPrintPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItem)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(38, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 26);
            this.label1.TabIndex = 92;
            this.label1.Text = "INVOICE ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(107)))), ((int)(((byte)(181)))));
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1334, 38);
            this.panel1.TabIndex = 189;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1235, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 38);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 93;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(9, 6);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 32);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(1268, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(33, 38);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 31;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(1301, 0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(33, 38);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 32;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 14F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(70, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 22);
            this.label3.TabIndex = 204;
            this.label3.Text = "Invoice Type*    :";
            // 
            // cmbInvTyp
            // 
            this.cmbInvTyp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInvTyp.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbInvTyp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.cmbInvTyp.FormattingEnabled = true;
            this.cmbInvTyp.Items.AddRange(new object[] {
            "FORIEGNER",
            "LOCAL"});
            this.cmbInvTyp.Location = new System.Drawing.Point(237, 63);
            this.cmbInvTyp.Margin = new System.Windows.Forms.Padding(2);
            this.cmbInvTyp.Name = "cmbInvTyp";
            this.cmbInvTyp.Size = new System.Drawing.Size(170, 32);
            this.cmbInvTyp.TabIndex = 238;
            this.cmbInvTyp.SelectedIndexChanged += new System.EventHandler(this.cmbInvTyp_SelectedIndexChanged);
            // 
            // txtInvNo
            // 
            this.txtInvNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.txtInvNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInvNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtInvNo.ForeColor = System.Drawing.Color.White;
            this.txtInvNo.Location = new System.Drawing.Point(436, 69);
            this.txtInvNo.Name = "txtInvNo";
            this.txtInvNo.Size = new System.Drawing.Size(132, 22);
            this.txtInvNo.TabIndex = 240;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Arial", 14F);
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(76, 491);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 22);
            this.label14.TabIndex = 208;
            this.label14.Text = "Title* :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.lblCost);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtCost);
            this.groupBox2.Controls.Add(this.dgvItem);
            this.groupBox2.Controls.Add(this.txtSpecification);
            this.groupBox2.Controls.Add(this.cmbItmTyp);
            this.groupBox2.Controls.Add(this.lblSpecification);
            this.groupBox2.Controls.Add(this.lblGemWeight);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.txtGemWeight);
            this.groupBox2.Controls.Add(this.txtNoPieces);
            this.groupBox2.Controls.Add(this.lblNoPieces);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(27, 118);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1485, 309);
            this.groupBox2.TabIndex = 196;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Stocks";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Arial", 14F);
            this.label28.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label28.Location = new System.Drawing.Point(18, 36);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(167, 22);
            this.label28.TabIndex = 144;
            this.label28.Text = "Stock Type*          :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(1284, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 16);
            this.label4.TabIndex = 113;
            this.label4.Text = "Show Img   :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(1287, 120);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 170);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 112;
            this.pictureBox1.TabStop = false;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.BackColor = System.Drawing.Color.Transparent;
            this.lblCost.Font = new System.Drawing.Font("Arial", 14F);
            this.lblCost.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCost.Location = new System.Drawing.Point(988, 87);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(72, 22);
            this.lblCost.TabIndex = 242;
            this.lblCost.Text = "Cost*  :";
            this.lblCost.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 14F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(18, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 22);
            this.label2.TabIndex = 15;
            this.label2.Text = "Search Stock No* :";
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(1070, 86);
            this.txtCost.Margin = new System.Windows.Forms.Padding(2);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(188, 26);
            this.txtCost.TabIndex = 241;
            this.txtCost.Visible = false;
            // 
            // dgvItem
            // 
            this.dgvItem.AllowUserToAddRows = false;
            this.dgvItem.AllowUserToDeleteRows = false;
            this.dgvItem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column8,
            this.Column9});
            this.dgvItem.Location = new System.Drawing.Point(22, 144);
            this.dgvItem.Name = "dgvItem";
            this.dgvItem.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.dgvItem.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvItem.RowTemplate.ReadOnly = true;
            this.dgvItem.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItem.Size = new System.Drawing.Size(1235, 149);
            this.dgvItem.TabIndex = 143;
            this.dgvItem.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItem_CellClick);
            this.dgvItem.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvItem_RowHeaderMouseDoubleClick);
            this.dgvItem.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgvItem_RowStateChanged);
            // 
            // Column2
            // 
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column2.HeaderText = "Stock_Type";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 8F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column3.HeaderText = "Stock_No";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Qty";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Item_Name";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Cost";
            this.Column6.Name = "Column6";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Weight";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Spec";
            this.Column9.Name = "Column9";
            this.Column9.Visible = false;
            // 
            // txtSpecification
            // 
            this.txtSpecification.Location = new System.Drawing.Point(1070, 38);
            this.txtSpecification.Margin = new System.Windows.Forms.Padding(2);
            this.txtSpecification.Name = "txtSpecification";
            this.txtSpecification.Size = new System.Drawing.Size(189, 26);
            this.txtSpecification.TabIndex = 203;
            this.txtSpecification.Visible = false;
            // 
            // cmbItmTyp
            // 
            this.cmbItmTyp.AllowDrop = true;
            this.cmbItmTyp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItmTyp.FormattingEnabled = true;
            this.cmbItmTyp.Items.AddRange(new object[] {
            "Gems",
            "Jewellery"});
            this.cmbItmTyp.Location = new System.Drawing.Point(201, 34);
            this.cmbItmTyp.Name = "cmbItmTyp";
            this.cmbItmTyp.Size = new System.Drawing.Size(127, 28);
            this.cmbItmTyp.TabIndex = 188;
            this.cmbItmTyp.SelectedIndexChanged += new System.EventHandler(this.ST_Type_SelectedIndexChanged);
            // 
            // lblSpecification
            // 
            this.lblSpecification.AutoSize = true;
            this.lblSpecification.BackColor = System.Drawing.Color.Transparent;
            this.lblSpecification.Font = new System.Drawing.Font("Arial", 14F);
            this.lblSpecification.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSpecification.Location = new System.Drawing.Point(927, 40);
            this.lblSpecification.Name = "lblSpecification";
            this.lblSpecification.Size = new System.Drawing.Size(134, 22);
            this.lblSpecification.TabIndex = 192;
            this.lblSpecification.Text = "Specification  :";
            this.lblSpecification.Visible = false;
            // 
            // lblGemWeight
            // 
            this.lblGemWeight.AutoSize = true;
            this.lblGemWeight.BackColor = System.Drawing.Color.Transparent;
            this.lblGemWeight.Font = new System.Drawing.Font("Arial", 14F);
            this.lblGemWeight.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblGemWeight.Location = new System.Drawing.Point(626, 89);
            this.lblGemWeight.Name = "lblGemWeight";
            this.lblGemWeight.Size = new System.Drawing.Size(145, 22);
            this.lblGemWeight.TabIndex = 26;
            this.lblGemWeight.Text = "Gem_Weight*  :";
            this.lblGemWeight.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(200, 88);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(128, 26);
            this.textBox1.TabIndex = 193;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtGemWeight
            // 
            this.txtGemWeight.Location = new System.Drawing.Point(773, 85);
            this.txtGemWeight.Margin = new System.Windows.Forms.Padding(2);
            this.txtGemWeight.Name = "txtGemWeight";
            this.txtGemWeight.Size = new System.Drawing.Size(104, 26);
            this.txtGemWeight.TabIndex = 199;
            this.txtGemWeight.Visible = false;
            // 
            // txtNoPieces
            // 
            this.txtNoPieces.Location = new System.Drawing.Point(773, 36);
            this.txtNoPieces.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoPieces.Name = "txtNoPieces";
            this.txtNoPieces.Size = new System.Drawing.Size(104, 26);
            this.txtNoPieces.TabIndex = 200;
            this.txtNoPieces.Visible = false;
            this.txtNoPieces.TextChanged += new System.EventHandler(this.txtNoPieces_TextChanged);
            // 
            // lblNoPieces
            // 
            this.lblNoPieces.AutoSize = true;
            this.lblNoPieces.BackColor = System.Drawing.Color.Transparent;
            this.lblNoPieces.Font = new System.Drawing.Font("Arial", 14F);
            this.lblNoPieces.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblNoPieces.Location = new System.Drawing.Point(625, 37);
            this.lblNoPieces.Name = "lblNoPieces";
            this.lblNoPieces.Size = new System.Drawing.Size(147, 22);
            this.lblNoPieces.TabIndex = 202;
            this.lblNoPieces.Text = "No. of Pieces*  :";
            this.lblNoPieces.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(15, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 19);
            this.label10.TabIndex = 194;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(744, 312);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 18);
            this.label18.TabIndex = 201;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.cmbTitle);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtCusNm);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(26, 451);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1486, 84);
            this.groupBox1.TabIndex = 209;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Details";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Arial", 14F);
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(251, 39);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(175, 22);
            this.label12.TabIndex = 103;
            this.label12.Text = "Customer Name*   :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Arial", 14F);
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(798, 40);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 22);
            this.label13.TabIndex = 104;
            this.label13.Text = "Country*   :";
            // 
            // cmbTitle
            // 
            this.cmbTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Items.AddRange(new object[] {
            "Mr. ",
            "Mrs.",
            "Miss.",
            "M/S",
            "Dr.",
            "Ven.",
            "Pros.",
            "Execellence"});
            this.cmbTitle.Location = new System.Drawing.Point(114, 37);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(98, 28);
            this.cmbTitle.TabIndex = 207;
            // 
            // txtAddress
            // 
            this.txtAddress.FormattingEnabled = true;
            this.txtAddress.Items.AddRange(new object[] {
            "",
            "China ",
            "American",
            "Sri lankan"});
            this.txtAddress.Location = new System.Drawing.Point(907, 37);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(213, 28);
            this.txtAddress.TabIndex = 210;
            // 
            // txtCusNm
            // 
            this.txtCusNm.Location = new System.Drawing.Point(448, 37);
            this.txtCusNm.Name = "txtCusNm";
            this.txtCusNm.Size = new System.Drawing.Size(278, 26);
            this.txtCusNm.TabIndex = 206;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(42, 370);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 19);
            this.label11.TabIndex = 205;
            // 
            // Invdelete
            // 
            this.Invdelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(80)))), ((int)(((byte)(114)))));
            this.Invdelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Invdelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Invdelete.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.Invdelete.Location = new System.Drawing.Point(1357, 63);
            this.Invdelete.Name = "Invdelete";
            this.Invdelete.Size = new System.Drawing.Size(212, 35);
            this.Invdelete.TabIndex = 245;
            this.Invdelete.Text = "Delete";
            this.Invdelete.UseVisualStyleBackColor = false;
            this.Invdelete.Visible = false;
            this.Invdelete.Click += new System.EventHandler(this.Invdelete_Click);
            // 
            // Dashlabel
            // 
            this.Dashlabel.AutoSize = true;
            this.Dashlabel.Location = new System.Drawing.Point(280, 68);
            this.Dashlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Dashlabel.Name = "Dashlabel";
            this.Dashlabel.Size = new System.Drawing.Size(61, 13);
            this.Dashlabel.TabIndex = 247;
            this.Dashlabel.Text = "------------------";
            // 
            // InvUpdate
            // 
            this.InvUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(80)))), ((int)(((byte)(114)))));
            this.InvUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.InvUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.InvUpdate.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.InvUpdate.Location = new System.Drawing.Point(1357, 63);
            this.InvUpdate.Name = "InvUpdate";
            this.InvUpdate.Size = new System.Drawing.Size(98, 35);
            this.InvUpdate.TabIndex = 244;
            this.InvUpdate.Text = "Update";
            this.InvUpdate.UseVisualStyleBackColor = false;
            this.InvUpdate.Visible = false;
            this.InvUpdate.Click += new System.EventHandler(this.InvUpdate_Click);
            // 
            // cmbCurrency1
            // 
            this.cmbCurrency1.FormattingEnabled = true;
            this.cmbCurrency1.Location = new System.Drawing.Point(190, 97);
            this.cmbCurrency1.Name = "cmbCurrency1";
            this.cmbCurrency1.Size = new System.Drawing.Size(130, 28);
            this.cmbCurrency1.TabIndex = 211;
            this.cmbCurrency1.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency1_SelectedIndexChanged);
            // 
            // cmbCardTyp
            // 
            this.cmbCardTyp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCardTyp.FormattingEnabled = true;
            this.cmbCardTyp.Location = new System.Drawing.Point(476, 37);
            this.cmbCardTyp.Name = "cmbCardTyp";
            this.cmbCardTyp.Size = new System.Drawing.Size(140, 28);
            this.cmbCardTyp.TabIndex = 215;
            // 
            // txtRate1
            // 
            this.txtRate1.Enabled = false;
            this.txtRate1.Location = new System.Drawing.Point(745, 95);
            this.txtRate1.Name = "txtRate1";
            this.txtRate1.Size = new System.Drawing.Size(138, 26);
            this.txtRate1.TabIndex = 219;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial", 14F);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(85, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 22);
            this.label6.TabIndex = 213;
            this.label6.Text = "Card Type :";
            // 
            // txtRate2
            // 
            this.txtRate2.Enabled = false;
            this.txtRate2.Location = new System.Drawing.Point(745, 192);
            this.txtRate2.Name = "txtRate2";
            this.txtRate2.Size = new System.Drawing.Size(139, 26);
            this.txtRate2.TabIndex = 220;
            // 
            // cmbPaymentTyp
            // 
            this.cmbPaymentTyp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPaymentTyp.FormattingEnabled = true;
            this.cmbPaymentTyp.Items.AddRange(new object[] {
            "None",
            "Credit",
            "Debit"});
            this.cmbPaymentTyp.Location = new System.Drawing.Point(190, 34);
            this.cmbPaymentTyp.Name = "cmbPaymentTyp";
            this.cmbPaymentTyp.Size = new System.Drawing.Size(130, 28);
            this.cmbPaymentTyp.TabIndex = 214;
            this.cmbPaymentTyp.SelectedIndexChanged += new System.EventHandler(this.cmbPaymentTyp_SelectedIndexChanged);
            // 
            // txtcardamt
            // 
            this.txtcardamt.Location = new System.Drawing.Point(745, 40);
            this.txtcardamt.Margin = new System.Windows.Forms.Padding(2);
            this.txtcardamt.Name = "txtcardamt";
            this.txtcardamt.Size = new System.Drawing.Size(139, 26);
            this.txtcardamt.TabIndex = 231;
            this.txtcardamt.TextChanged += new System.EventHandler(this.txtAmt1_TextChanged);
            // 
            // lblcardamt
            // 
            this.lblcardamt.AutoSize = true;
            this.lblcardamt.BackColor = System.Drawing.Color.Transparent;
            this.lblcardamt.Font = new System.Drawing.Font("Arial", 14F);
            this.lblcardamt.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblcardamt.Location = new System.Drawing.Point(636, 42);
            this.lblcardamt.Name = "lblcardamt";
            this.lblcardamt.Size = new System.Drawing.Size(90, 22);
            this.lblcardamt.TabIndex = 232;
            this.lblcardamt.Text = "Amount  :";
            // 
            // txtRate3
            // 
            this.txtRate3.Enabled = false;
            this.txtRate3.Location = new System.Drawing.Point(745, 236);
            this.txtRate3.Name = "txtRate3";
            this.txtRate3.Size = new System.Drawing.Size(139, 26);
            this.txtRate3.TabIndex = 223;
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.Enabled = false;
            this.txtTotalAmount.Location = new System.Drawing.Point(1168, 78);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.Size = new System.Drawing.Size(201, 26);
            this.txtTotalAmount.TabIndex = 163;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Arial", 14F);
            this.label22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Location = new System.Drawing.Point(662, 192);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 22);
            this.label22.TabIndex = 221;
            this.label22.Text = "Rate  :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Arial", 14F);
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(661, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 22);
            this.label20.TabIndex = 218;
            this.label20.Text = "Rate  :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Arial", 14F);
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Location = new System.Drawing.Point(662, 238);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 22);
            this.label23.TabIndex = 224;
            this.label23.Text = "Rate  :";
            // 
            // lblCardTyp
            // 
            this.lblCardTyp.AutoSize = true;
            this.lblCardTyp.BackColor = System.Drawing.Color.Transparent;
            this.lblCardTyp.Font = new System.Drawing.Font("Arial", 14F);
            this.lblCardTyp.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCardTyp.Location = new System.Drawing.Point(344, 38);
            this.lblCardTyp.Name = "lblCardTyp";
            this.lblCardTyp.Size = new System.Drawing.Size(127, 22);
            this.lblCardTyp.TabIndex = 52;
            this.lblCardTyp.Text = "Card Vendor :";
            // 
            // txtAmt1
            // 
            this.txtAmt1.Location = new System.Drawing.Point(476, 94);
            this.txtAmt1.Name = "txtAmt1";
            this.txtAmt1.Size = new System.Drawing.Size(140, 26);
            this.txtAmt1.TabIndex = 225;
            this.txtAmt1.TextChanged += new System.EventHandler(this.txtAmt1_TextChanged);
            this.txtAmt1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAmt1_KeyDown);
            // 
            // txtTot1
            // 
            this.txtTot1.Enabled = false;
            this.txtTot1.Location = new System.Drawing.Point(958, 97);
            this.txtTot1.Name = "txtTot1";
            this.txtTot1.Size = new System.Drawing.Size(133, 26);
            this.txtTot1.TabIndex = 234;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Arial", 14F);
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Location = new System.Drawing.Point(100, 192);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 22);
            this.label24.TabIndex = 75;
            this.label24.Text = "OCT  :";
            // 
            // btnPrntInvoice
            // 
            this.btnPrntInvoice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPrntInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrntInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrntInvoice.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnPrntInvoice.Location = new System.Drawing.Point(1168, 138);
            this.btnPrntInvoice.Name = "btnPrntInvoice";
            this.btnPrntInvoice.Size = new System.Drawing.Size(210, 52);
            this.btnPrntInvoice.TabIndex = 126;
            this.btnPrntInvoice.Text = "PRINT INVOICE";
            this.btnPrntInvoice.UseVisualStyleBackColor = true;
            this.btnPrntInvoice.Click += new System.EventHandler(this.btnPrntInvoice_Click);
            // 
            // txtTot2
            // 
            this.txtTot2.Enabled = false;
            this.txtTot2.Location = new System.Drawing.Point(959, 192);
            this.txtTot2.Name = "txtTot2";
            this.txtTot2.Size = new System.Drawing.Size(133, 26);
            this.txtTot2.TabIndex = 236;
            // 
            // txtAmt2
            // 
            this.txtAmt2.Enabled = false;
            this.txtAmt2.Location = new System.Drawing.Point(477, 190);
            this.txtAmt2.Name = "txtAmt2";
            this.txtAmt2.Size = new System.Drawing.Size(140, 26);
            this.txtAmt2.TabIndex = 227;
            this.txtAmt2.TextChanged += new System.EventHandler(this.txtAmt1_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Arial", 14F);
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(351, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 22);
            this.label9.TabIndex = 226;
            this.label9.Text = "CT.Amount  :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Arial", 14F);
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Location = new System.Drawing.Point(1197, 34);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(154, 22);
            this.label21.TabIndex = 65;
            this.label21.Text = "Total Payment    :";
            // 
            // txtTot3
            // 
            this.txtTot3.Enabled = false;
            this.txtTot3.Location = new System.Drawing.Point(959, 238);
            this.txtTot3.Name = "txtTot3";
            this.txtTot3.Size = new System.Drawing.Size(133, 26);
            this.txtTot3.TabIndex = 237;
            // 
            // cmbCurrency2
            // 
            this.cmbCurrency2.Enabled = false;
            this.cmbCurrency2.FormattingEnabled = true;
            this.cmbCurrency2.Location = new System.Drawing.Point(171, 190);
            this.cmbCurrency2.Name = "cmbCurrency2";
            this.cmbCurrency2.Size = new System.Drawing.Size(130, 28);
            this.cmbCurrency2.TabIndex = 216;
            this.cmbCurrency2.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency1_SelectedIndexChanged);
            // 
            // txtAmt3
            // 
            this.txtAmt3.Enabled = false;
            this.txtAmt3.Location = new System.Drawing.Point(477, 234);
            this.txtAmt3.Name = "txtAmt3";
            this.txtAmt3.Size = new System.Drawing.Size(140, 26);
            this.txtAmt3.TabIndex = 229;
            this.txtAmt3.TextChanged += new System.EventHandler(this.txtAmt1_TextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Arial", 14F);
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(352, 190);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(119, 22);
            this.label25.TabIndex = 228;
            this.label25.Text = "CT.Amount  :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label29.Location = new System.Drawing.Point(913, 103);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 18);
            this.label29.TabIndex = 235;
            this.label29.Text = ">>";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Arial", 14F);
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label26.Location = new System.Drawing.Point(352, 238);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(119, 22);
            this.label26.TabIndex = 230;
            this.label26.Text = "CT.Amount  :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial", 14F);
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(6, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(186, 22);
            this.label5.TabIndex = 212;
            this.label5.Text = "Currency Type (CT) :";
            // 
            // cmbCurrency3
            // 
            this.cmbCurrency3.Enabled = false;
            this.cmbCurrency3.FormattingEnabled = true;
            this.cmbCurrency3.Location = new System.Drawing.Point(171, 234);
            this.cmbCurrency3.Name = "cmbCurrency3";
            this.cmbCurrency3.Size = new System.Drawing.Size(130, 28);
            this.cmbCurrency3.TabIndex = 222;
            this.cmbCurrency3.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency1_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Arial", 14F);
            this.label19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Location = new System.Drawing.Point(100, 236);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 22);
            this.label19.TabIndex = 217;
            this.label19.Text = "OCT  :";
            // 
            // checkBox_disable
            // 
            this.checkBox_disable.AutoSize = true;
            this.checkBox_disable.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.checkBox_disable.Location = new System.Drawing.Point(20, 146);
            this.checkBox_disable.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox_disable.Name = "checkBox_disable";
            this.checkBox_disable.Size = new System.Drawing.Size(314, 28);
            this.checkBox_disable.TabIndex = 139;
            this.checkBox_disable.Text = "Optional Currency Type (OCT)";
            this.checkBox_disable.UseVisualStyleBackColor = true;
            this.checkBox_disable.CheckedChanged += new System.EventHandler(this.checkBox_disable_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(914, 196);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 18);
            this.label16.TabIndex = 187;
            this.label16.Text = ">>";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Location = new System.Drawing.Point(914, 243);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 18);
            this.label17.TabIndex = 188;
            this.label17.Text = ">>";
            // 
            // Print_invoice_Pre
            // 
            this.Print_invoice_Pre.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Print_invoice_Pre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Print_invoice_Pre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Print_invoice_Pre.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Print_invoice_Pre.Location = new System.Drawing.Point(1535, 139);
            this.Print_invoice_Pre.Name = "Print_invoice_Pre";
            this.Print_invoice_Pre.Size = new System.Drawing.Size(149, 52);
            this.Print_invoice_Pre.TabIndex = 238;
            this.Print_invoice_Pre.Text = "PREVIEW";
            this.Print_invoice_Pre.UseVisualStyleBackColor = true;
            // 
            // Print_certificate_Pre
            // 
            this.Print_certificate_Pre.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Print_certificate_Pre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Print_certificate_Pre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Print_certificate_Pre.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Print_certificate_Pre.Location = new System.Drawing.Point(1535, 220);
            this.Print_certificate_Pre.Name = "Print_certificate_Pre";
            this.Print_certificate_Pre.Size = new System.Drawing.Size(149, 52);
            this.Print_certificate_Pre.TabIndex = 239;
            this.Print_certificate_Pre.Text = "PREVIEW";
            this.Print_certificate_Pre.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Print_certificate_Pre);
            this.groupBox4.Controls.Add(this.Print_invoice_Pre);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.checkBox_disable);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.cmbCurrency3);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.txtAmt3);
            this.groupBox4.Controls.Add(this.cmbCurrency2);
            this.groupBox4.Controls.Add(this.txtTot3);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.txtAmt2);
            this.groupBox4.Controls.Add(this.txtTot2);
            this.groupBox4.Controls.Add(this.btnPrntInvoice);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.txtTot1);
            this.groupBox4.Controls.Add(this.txtAmt1);
            this.groupBox4.Controls.Add(this.lblCardTyp);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.txtTotalAmount);
            this.groupBox4.Controls.Add(this.txtRate3);
            this.groupBox4.Controls.Add(this.lblcardamt);
            this.groupBox4.Controls.Add(this.txtcardamt);
            this.groupBox4.Controls.Add(this.cmbPaymentTyp);
            this.groupBox4.Controls.Add(this.txtRate2);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.txtRate1);
            this.groupBox4.Controls.Add(this.cmbCardTyp);
            this.groupBox4.Controls.Add(this.cmbCurrency1);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(26, 552);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(1486, 278);
            this.groupBox4.TabIndex = 233;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Payment Method";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // btnaddstock
            // 
            this.btnaddstock.AutoSize = true;
            this.btnaddstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnaddstock.Location = new System.Drawing.Point(385, 205);
            this.btnaddstock.Name = "btnaddstock";
            this.btnaddstock.Size = new System.Drawing.Size(107, 27);
            this.btnaddstock.TabIndex = 198;
            this.btnaddstock.Text = "Search";
            this.btnaddstock.UseVisualStyleBackColor = true;
            this.btnaddstock.Click += new System.EventHandler(this.btnaddstock_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(80)))), ((int)(((byte)(114)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button3.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.button3.Location = new System.Drawing.Point(1138, 63);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(212, 35);
            this.button3.TabIndex = 246;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // PrntInPre
            // 
            this.PrntInPre.Location = new System.Drawing.Point(1419, 697);
            this.PrntInPre.Name = "PrntInPre";
            this.PrntInPre.Size = new System.Drawing.Size(75, 38);
            this.PrntInPre.TabIndex = 240;
            this.PrntInPre.Text = "Preview";
            this.PrntInPre.UseVisualStyleBackColor = true;
            this.PrntInPre.Click += new System.EventHandler(this.PrntInPre_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // DVPrintPreviewDialog
            // 
            this.DVPrintPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.DVPrintPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.DVPrintPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.DVPrintPreviewDialog.Document = this.DVPrintDocument;
            this.DVPrintPreviewDialog.Enabled = true;
            this.DVPrintPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("DVPrintPreviewDialog.Icon")));
            this.DVPrintPreviewDialog.Name = "DVPrintPreviewDialog";
            this.DVPrintPreviewDialog.Visible = false;
            // 
            // DVPrintDocument
            // 
            this.DVPrintDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.DVPrintDocument_PrintPage);
            // 
            // INPrintDocument
            // 
            this.INPrintDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.INPrintDocument_PrintPage);
            // 
            // btnremovestock
            // 
            this.btnremovestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnremovestock.Location = new System.Drawing.Point(498, 206);
            this.btnremovestock.Name = "btnremovestock";
            this.btnremovestock.Size = new System.Drawing.Size(107, 26);
            this.btnremovestock.TabIndex = 197;
            this.btnremovestock.Text = "Add Stock";
            this.btnremovestock.UseVisualStyleBackColor = true;
            this.btnremovestock.Click += new System.EventHandler(this.btnremovestock_Click);
            // 
            // INPrintPreviewDialog
            // 
            this.INPrintPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.INPrintPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.INPrintPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.INPrintPreviewDialog.Enabled = true;
            this.INPrintPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("INPrintPreviewDialog.Icon")));
            this.INPrintPreviewDialog.Name = "INPrintPreviewDialog";
            this.INPrintPreviewDialog.Visible = false;
            // 
            // Column1
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 8F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column1.HeaderText = "No";
            this.Column1.Name = "Column1";
            // 
            // In_certi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(85)))), ((int)(((byte)(114)))));
            this.ClientSize = new System.Drawing.Size(1334, 811);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.PrntInPre);
            this.Controls.Add(this.btnremovestock);
            this.Controls.Add(this.btnaddstock);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.txtInvNo);
            this.Controls.Add(this.cmbInvTyp);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Dashlabel);
            this.Controls.Add(this.Invdelete);
            this.Controls.Add(this.InvUpdate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "In_certi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "s";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.In_certi_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItem)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbInvTyp;
        public System.Windows.Forms.TextBox txtInvNo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.DataGridView dgvItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.TextBox txtSpecification;
        private System.Windows.Forms.ComboBox cmbItmTyp;
        private System.Windows.Forms.Label lblSpecification;
        private System.Windows.Forms.Label lblGemWeight;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtGemWeight;
        private System.Windows.Forms.TextBox txtNoPieces;
        private System.Windows.Forms.Label lblNoPieces;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        public System.Windows.Forms.ComboBox cmbTitle;
        public System.Windows.Forms.ComboBox txtAddress;
        public System.Windows.Forms.TextBox txtCusNm;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Invdelete;
        private System.Windows.Forms.Label Dashlabel;
        public System.Windows.Forms.Button InvUpdate;
        private System.Windows.Forms.ComboBox cmbCurrency1;
        private System.Windows.Forms.ComboBox cmbCardTyp;
        private System.Windows.Forms.TextBox txtRate1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtRate2;
        private System.Windows.Forms.ComboBox cmbPaymentTyp;
        private System.Windows.Forms.TextBox txtcardamt;
        private System.Windows.Forms.Label lblcardamt;
        private System.Windows.Forms.TextBox txtRate3;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblCardTyp;
        private System.Windows.Forms.TextBox txtAmt1;
        private System.Windows.Forms.TextBox txtTot1;
        private System.Windows.Forms.Label label24;
        public System.Windows.Forms.Button btnPrntInvoice;
        private System.Windows.Forms.TextBox txtTot2;
        private System.Windows.Forms.TextBox txtAmt2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtTot3;
        private System.Windows.Forms.ComboBox cmbCurrency2;
        private System.Windows.Forms.TextBox txtAmt3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbCurrency3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox checkBox_disable;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button Print_invoice_Pre;
        private System.Windows.Forms.Button Print_certificate_Pre;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnaddstock;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button PrntInPre;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btnremovestock;
        private System.Windows.Forms.PrintPreviewDialog DVPrintPreviewDialog;
        private System.Drawing.Printing.PrintDocument DVPrintDocument;
        private System.Drawing.Printing.PrintDocument INPrintDocument;
        private System.Windows.Forms.PrintPreviewDialog INPrintPreviewDialog;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
    }
}